# if.04.22 Procedural Programming

## Coding Assignment "Excess"

### Objective
This assignment is to give you more training in reading and displaying text files.

### Required Task
Read the [Assignment](Assignment.pdf) carefully and implement a c program as required. 
