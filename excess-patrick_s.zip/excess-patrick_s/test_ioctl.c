#include <sys/ioctl.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

/*struct winsize{
		int ws_row;
		int ws_col;
		int ws_pixel;
		int ws_ypixel;
}*/

void Next(struct winsize* ws, FILE * fd,int page);

int main(int argc,char *argv[])
{
	FILE * fd = fopen(argv[1],"r");
	//fprintf(stdout, "Print some data to stdout.\n\n");
	//print the page
	struct winsize ws;

	if (ioctl(0,TIOCGWINSZ,&ws)!=0) {
		fprintf(stderr,"TIOCGWINSZ:%s\n",strerror(errno));
		exit(-1);
	}
	Next(&ws,fd,0);

	printf("row=%d, col=%d, xpixel=%d, ypixel=%d\n",
	ws.ws_row,ws.ws_col,ws.ws_xpixel,ws.ws_ypixel);
	fclose(fd);
	printf("%s\n",argv[1] );
	return 0;
}

void Next(struct winsize *ws, FILE * fd,int page)
{

	fseek(fd,0,SEEK_SET);
	if(fd == 0)
	{
		return;
	}


	int i = 0;
	while(i <= page)
	{
		system("clear");
		char *array = malloc(sizeof(char)* (ws->ws_col+1));

		for(int r = 0; r < ws->ws_row && !feof(fd);r++)
		{
			fgets(array,ws->ws_col,fd);
			printf("%s",array );
		}

		i ++;

		free(array);
	}


	char aChar;
	aChar = getchar();
	if(aChar == '\n' &&  !feof(fd))
	{
		Next(ws,fd,page+1);
	}

	else if(aChar != '\n')
	{
		while(aChar != '\n')
		aChar = getchar();
			Next(ws,fd,page);


	}

	else if( aChar == 'b' && page > 0)
	{
		while(aChar != '\n')
		aChar= getchar();
			Next(ws,fd,page-1);
	}


}
